const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = __dirname;
const HOST = process.env.HOST || '0.0.0.0';
const PORT = Number(process.env.PORT) || 8766;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'online-data.json');
const READER = 'https://r.jina.ai/';
const MAX_BODY = 64 * 1024;
const MIN_READER_INTERVAL_MS = 3100;

let onlineData = { users:[], sessions:[], messages:[] };
try { onlineData = { ...onlineData, ...JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')) }; } catch {}
const onlinePresence = new Map();
function saveOnlineData() {
  fs.mkdirSync(DATA_DIR, { recursive:true });
  const temp = DATA_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(onlineData), { mode:0o600 });
  fs.renameSync(temp, DATA_FILE);
}
function sha256(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function publicUser(user) { return { id:user.id, name:user.name, email:user.email }; }
function getCookie(req, key) {
  const cookies = String(req.headers.cookie||'').split(';');
  for (const cookie of cookies) { const i=cookie.indexOf('='); if(i>0 && cookie.slice(0,i).trim()===key) return decodeURIComponent(cookie.slice(i+1).trim()); }
  return '';
}
function currentUser(req) {
  const token=getCookie(req,'zakazkar_session'); if(!token) return null;
  const session=onlineData.sessions.find(s=>s.tokenHash===sha256(token)&&s.expires>Date.now());
  const user=session ? onlineData.users.find(u=>u.id===session.userId) || null : null;
  if(user) onlinePresence.set(user.id,Date.now());
  return user;
}
function readJson(req, max=16*1024) {
  return new Promise((resolve,reject)=>{
    let raw='';
    req.on('data',chunk=>{ raw+=chunk; if(Buffer.byteLength(raw)>max){reject(Object.assign(new Error('Požadavek je příliš velký.'),{status:413}));req.destroy();} });
    req.on('end',()=>{try{resolve(JSON.parse(raw||'{}'));}catch{reject(Object.assign(new Error('Neplatná data.'),{status:400}));}});
    req.on('error',reject);
  });
}
function setSessionCookie(req,res,token) {
  const secure = req.socket.encrypted || String(req.headers['x-forwarded-proto']||'').split(',')[0].trim()==='https';
  res.setHeader('Set-Cookie', `zakazkar_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=2592000${secure?'; Secure':''}`);
}
function requireUser(req,res) { const user=currentUser(req); if(!user) json(res,401,{error:'Pro chat se přihlaste ke svému účtu.'}); return user; }
function newId() { return crypto.randomUUID(); }
const authAttempts = new Map();
function authRateLimited(req) {
  const ip=req.socket.remoteAddress||'unknown', now=Date.now(), old=authAttempts.get(ip)||[];
  const recent=old.filter(t=>now-t<10*60*1000); recent.push(now); authAttempts.set(ip,recent);
  return recent.length>30;
}

// Only public, non-governmental sources used for real service and trade leads.
const SOURCES = [
  { id:'epoptavka', name:'ePoptávka.cz', url:'https://poptavky.epoptavka.cz/moravskoslezsky-kraj', regionScoped:true, kind:'Poptávka' },
  { id:'poptavej', name:'Poptávej.cz — řemesla MSK', url:'https://www.poptavej.cz/poptavky/remesla/kraj-moravskoslezsky', regionScoped:true, kind:'Poptávka' },
  { id:'poptavky', name:'Poptávky.cz', url:'https://www.poptavky.cz/poptavky/moravskoslezsky-kraj', regionScoped:true, kind:'Poptávka' },
  { id:'nejremeslnici', name:'Nejřemeslníci.cz', url:'https://nejremeslnici.cz/poptavky?kraj=moravskoslezsky', regionScoped:true, kind:'Poptávka' },
  { id:'poptavkaeu', name:'Poptávka-EU.cz', url:'https://www.poptavka-eu.cz/kraje/CZ080/?filter=0', regionScoped:true, kind:'Poptávka' },
  { id:'trh', name:'TrhPoptávek.cz', url:'https://trhpoptavek.cz/remesla/moravskoslezsky-kraj', regionScoped:true, kind:'Poptávka' },
  { id:'zakazky', name:'Zakázky.služby.cz', url:'https://zakazky.sluzby.cz/remesla-profese/moravskoslezsky-kraj', regionScoped:true, kind:'Poptávka' },
  { id:'aaapoptavka', name:'AAA Poptávka.cz', url:'https://www.aaapoptavka.cz/poptavky/prace', regionScoped:false, kind:'Poptávka' },
  { id:'aaasubdodavky', name:'AAA Poptávka — subdodávky', url:'https://www.aaapoptavka.cz/poptavky/subdodavky', regionScoped:false, kind:'Poptávka' },
  { id:'pop24', name:'Pop24.cz', url:'https://pop24.cz/', regionScoped:false, kind:'Poptávka' },
  { id:'hledamruce', name:'Hledám ruce', url:'https://www.hledamruce.cz/', regionScoped:false, kind:'Poptávka' },
  { id:'ceskestavby', name:'ČESKÉSTAVBY.cz — poptávky', url:'https://www.ceskestavby.cz/poptavka/', regionScoped:false, kind:'Poptávka' },
  { id:'dohodni', name:'Dohodni.cz', url:'https://dohodni.com/', regionScoped:false, kind:'Poptávka' },
  { id:'ubo', name:'UBO.cz', url:'https://www.ubo.cz/', regionScoped:false, kind:'Poptávka' },
  { id:'dalbovac', name:'Dalbovač.cz', url:'https://www.dalbovac.cz/', regionScoped:false, kind:'Poptávka' },
  { id:'nejstav', name:'NejStav.cz', url:'https://nejstav.cz/', regionScoped:false, kind:'Poptávka' },
  { id:'avizo', name:'Avízo.cz (služby a řemesla)', url:'https://www.avizo.cz/sluzby-remesla/', regionScoped:false, kind:'Inzerát/služba', requestOnly:true },
  { id:'bazos', name:'Bazoš.cz (služby)', url:'https://sluzby.bazos.cz/moravskoslezsky/', regionScoped:true, kind:'Inzerát/služba', requestOnly:true },
  { id:'sbazar', name:'Sbazar.cz (služby)', url:'https://www.sbazar.cz/sluzby', regionScoped:false, kind:'Inzerát/služba', requestOnly:true },
  { id:'supersoused', name:'SuperSoused.cz', url:'https://www.supersoused.cz/', regionScoped:false, kind:'Poptávka', requestOnly:true },
  { id:'nevyhazujto', name:'Nevyhazujto.cz', url:'https://www.nevyhazujto.cz/', regionScoped:false, kind:'Inzerát/služba', requestOnly:true },
  { id:'vsezaodvoz', name:'Všezaodvoz.cz', url:'https://www.vsezaodvoz.cz/', regionScoped:false, kind:'Inzerát/služba', requestOnly:true }
];
const SOURCE_BY_ID = new Map(SOURCES.map(source => [source.id, source]));
const CITIES = ['Ostrava','Opava','Karviná','Havířov','Frýdek-Místek','Frýdek','Třinec','Nový Jičín','Bohumín','Bruntál','Krnov','Vítkov','Odry','Hlučín','Bílovec','Studénka','Jablunkov','Český Těšín','Kopřivnice','Příbor','Frenštát','Rýmařov','Ostravice','Orlová','Třebovice','Vítkovice','Bítov','Albrechtice'];
const REGION_HINTS = ['moravskoslezský','moravskoslezsko','ostravsko','opavsko','těšínsko','hlučínsko','severní morava','severomoravský','bruntálsko','karvinsko'];
const ALIASES = {
  'stěhování':['stěhovací','přestěhování','stěhovat'],
  'vyklízení':['vyklízení','vyklízecí','vyklizení','vyklidit'],
  'odvoz':['odvoz','suti','sutě','suť','odpadu','odpadů','stavebního odpadu'],
  'kontejner':['kontejner','kontejnery','kontejneru'],
  'bourání':['bourání','bourací','bourat','demolice','demoliční'],
  'likvidace':['likvidace','likvidovat','odstranění odpadu'],
  'zedník':['zedník','zednické','zednický','zednických'],
  'instalatér':['instalatér','instalatérské','instalatérský','instalace vody'],
  'topenář':['topenář','topenářské','topenářský','vytápění'],
  'obkladač':['obkladač','obkladačské','obklady a dlažby'],
  'elektrikář':['elektrikář','elektroinstalace','elektroinstalační'],
  'podlahář':['podlahář','podlahářské','pokládka podlah'],
  'malíř':['malíř','malířské','výmalba','malování'],
  'klempíř':['klempíř','klempířské'],
  'tesař':['tesař','tesařské'],
  'truhlář':['truhlář','truhlářské'],
  'omítky':['omítky','omítka','omítání'],
  'sádrokarton':['sádrokarton','sdk','sádrokartonářské'],
  'střecha':['střecha','střechy','střešní','krytina'],
  'beton':['beton','betonáž','betonování'],
  'klimatizace':['klimatizace','klimatizaci','klimatizační'],
  'plyn':['plyn','plynový','plynové'],
  'kontejner':['kontejner','kontejnery','kontejneru']
};
let nextReaderStart = 0;

function send(res, status, body, type = 'application/json; charset=utf-8') {
  const data = Buffer.isBuffer(body) ? body : Buffer.from(String(body));
  res.writeHead(status, { 'Content-Type': type, 'Content-Length': data.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(data);
}
function json(res, status, data) { return send(res, status, JSON.stringify(data)); }
function normalize(text) {
  return String(text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}
function decodeText(text) {
  return String(text || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;|&#160;/gi, ' ').replace(/&amp;/gi, '&').replace(/&quot;/gi, '"').replace(/&#39;|&apos;/gi, "'").replace(/&lt;/gi, '<').replace(/&gt;/gi, '>').replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/\s+/g, ' ').trim();
}
function cleanMarkdown(text) {
  return decodeText(String(text || '').replace(/!\[[^\]]*\]\([^)]*\)/g, ' ').replace(/\[([^\]]+)\]\([^)]*\)/g, '$1').replace(/[`*_>#]/g, ' '));
}
function matchesWork(text, keywords) {
  const corpus = normalize(text);
  return keywords.some(keyword => {
    const key = normalize(keyword);
    if (key && corpus.includes(key)) return true;
    const aliases = ALIASES[keyword] || ALIASES[key] || [];
    return aliases.some(alias => corpus.includes(normalize(alias)));
  });
}
function isInRegion(text) {
  const value = normalize(text);
  if (CITIES.some(city => value.includes(normalize(city)))) return true;
  if (REGION_HINTS.some(hint => value.includes(normalize(hint)))) return true;
  return /\b(7[0-4]\d|78\d|79\d)\s?\d{2}\b/.test(String(text));
}
function detectLocation(text, regionScoped) {
  const value = normalize(text);
  for (const city of CITIES) if (value.includes(normalize(city))) return `MSK · ${city}`;
  if (REGION_HINTS.some(hint => value.includes(normalize(hint)))) return 'Moravskoslezský kraj';
  return regionScoped ? 'Moravskoslezský kraj' : 'Lokalitu ověřte na portálu';
}
function normalizeUrl(href, baseUrl) {
  try {
    const url = new URL(href, baseUrl);
    if (!['http:','https:'].includes(url.protocol)) return null;
    return url.href.split('#')[0];
  } catch { return null; }
}
function rootHost(host) {
  const parts = String(host || '').toLowerCase().replace(/^www\./, '').split('.');
  return parts.length > 2 ? parts.slice(-2).join('.') : parts.join('.');
}
function hasCustomerRequestIntent(text) {
  const value = normalize(text);
  return /(poptav|hledam|hledame|shanim|shanime|potrebuji|potrebujeme|poptavam|poptavame|rad bych|prosim o|zakazku|zakazka|oprava|rekonstrukce|montaz|realizace|vymena|instalace|vyroba|zhotoveni|pokladka|bourani|vyklizeni|stehovani|odvoz|demontaz|zatepleni|vymalba|malovani|omitani|betonaz|likvidace|opravit|postavit)/.test(value);
}
function intentIsRealRequest(text, source) {
  const value = normalize(text);
  if (/(vytvorte si zdarma|uspesne ukonceno|vyzkouset nyni|vlastni www stranky|e shop|webove stranky|registrace|prihlaseni|volne misto|pracovni pozice|pracovni nabidka|zivotopis|mzda|nastup ihned|prijmeme|hledame zamestnance)/.test(value)) return false;
  if (/verejn.{0,16}zakaz|statn.{0,12}zakaz|zad[aá]vac[ií] r[ií]zen[ií]|verejn[yý] zadavatel|tender|vyberov[eé] r[ií]zen[ií]/i.test(value)) return false;
  if (!hasCustomerRequestIntent(value)) return false;
  if (source.requestOnly && !/(poptav|hledam|hledame|shanim|shanime|potrebuji|potrebujeme|poptavam|poptavame|zakazku|zakazka|nabidnete|odvoz sut|odvoz odpadu)/.test(value)) return false;
  return true;
}
function extractDate(text) {
  const value = decodeText(text);
  const match = value.match(/(?:Dnes|Včera|Předevčírem)\s+\d{1,2}:\d{2}|\b\d{1,2}\.\s*\d{1,2}\.\s*20\d{2}\b|\bpřed\s+\d+\s+(?:minutami?|hodinami?|dny?)\b/i);
  return match ? match[0] : '';
}
function extractCandidates(markdown, source, keywords) {
  const lines = String(markdown || '').replace(/\r/g, '').split('\n');
  const results = [], seen = new Set();
  const linkPattern = /\[([^\]]{5,240})\]\((https?:\/\/[^\s)]+)(?:\s+"[^"]*")?\)/g;
  for (let i = 0; i < lines.length; i++) {
    linkPattern.lastIndex = 0;
    let match;
    while ((match = linkPattern.exec(lines[i])) !== null) {
      const title = decodeText(match[1].replace(/\*\*/g, '')).replace(/^[\W_]+|[\W_]+$/gu, '').trim();
      const url = normalizeUrl(match[2], source.url);
      if (!url || title.length < 18 || title.length > 220) continue;
      if (/^(image\s*\d*|obrazek|logo|registrace|přihlásit|registrovat|více|firmy|kontakt|nápověda|hledat|filtr|poptávky|kategorie|ceník|podmínky)\b/i.test(title)) continue;
      if (/(vytvorte si zdarma|uspesne ukonceno|vyzkouset nyni|vlastni www stranky|e shop|webove stranky|registrace)/i.test(normalize(title))) continue;
      const parsed = new URL(url);
      if (rootHost(parsed.hostname) !== rootHost(new URL(source.url).hostname)) continue;
      if (url === normalizeUrl(source.url, source.url)) continue;
      const before = lines[i].slice(0, match.index), after = lines[i].slice(match.index + match[0].length);
      const previousBoundary = Math.max(before.lastIndexOf(')'), before.lastIndexOf(']'));
      const nextLink = /\[[^\]]*\]\(/.exec(after);
      const localBefore = previousBoundary >= 0 ? before.slice(previousBoundary + 1) : before.slice(-220);
      const localAfter = nextLink ? after.slice(0, nextLink.index) : after.slice(0, 260);
      let localText = localBefore + ' ' + title + ' ' + localAfter;
      for (const neighbor of [i - 1, i + 1]) {
        if (neighbor >= 0 && neighbor < lines.length && lines[neighbor].length <= 240 && !/\[[^\]]+\]\(https?:\/\//.test(lines[neighbor])) localText += ' ' + lines[neighbor];
      }
      const context = cleanMarkdown(localText).slice(0, 500), corpus = title + ' ' + context;
      if (!matchesWork(corpus, keywords) || !intentIsRealRequest(corpus, source)) continue;
      if (!source.regionScoped && !isInRegion(corpus)) continue;
      const location = detectLocation(corpus, source.regionScoped), signature = normalize(title) + '|' + normalize(location);
      if (seen.has(url) || seen.has(signature)) continue;
      seen.add(url); seen.add(signature);
      results.push({ title, url, location, excerpt:context.replace(title, '').replace(/\s+/g, ' ').trim().slice(0, 220), postedLabel:extractDate(context), source:source.name, kind:source.kind });
      if (results.length >= 80) return results;
    }
  }
  return results;
}
function wait(ms) { return ms > 0 ? new Promise(resolve => setTimeout(resolve, ms)) : Promise.resolve(); }
async function fetchReaderPage(source) {
  const start = Math.max(Date.now(), nextReaderStart);
  nextReaderStart = start + MIN_READER_INTERVAL_MS;
  await wait(start - Date.now());
  const response = await fetch(READER + source.url, {
    headers: { 'Accept': 'text/plain', 'X-Return-Format': 'markdown' },
    signal: AbortSignal.timeout(22000)
  });
  if (!response.ok) throw new Error(`Čtečka zdroje odpověděla HTTP ${response.status}`);
  const text = await response.text();
  if (text.length < 100) throw new Error('Zdroj vrátil prázdný výpis');
  return text;
}
async function scanOne(source, keywords) {
  try {
    const page = await fetchReaderPage(source);
    const items = extractCandidates(page, source, keywords);
    return { sourceId:source.id, source:source.name, count:items.length, items };
  } catch (error) {
    return { sourceId:source.id, source:source.name, count:0, items:[], error:error.name === 'TimeoutError' ? 'Vypršel čas načítání' : String(error.message || error).slice(0, 160) };
  }
}
async function scanSources(sourceIds, keywords) {
  const selected = sourceIds.map(id => SOURCE_BY_ID.get(id)).filter(Boolean);
  const summaries = new Array(selected.length);
  let cursor = 0;
  async function worker() {
    while (true) {
      const index = cursor++;
      if (index >= selected.length) return;
      summaries[index] = await scanOne(selected[index], keywords);
    }
  }
  await Promise.all(Array.from({ length: Math.min(3, selected.length) }, worker));
  const items = summaries.flatMap(summary => summary.items);
  const unique = new Map();
  for (const item of items) {
    const key = item.url || `${normalize(item.title)}|${normalize(item.location)}`;
    if (!unique.has(key)) unique.set(key, item);
  }
  return { items:[...unique.values()].sort((a,b) => (b.postedLabel ? 1 : 0) - (a.postedLabel ? 1 : 0)), sources:summaries, totalSources:selected.length, completedSources:summaries.filter(s => !s.error).length };
}

function sendHtml(res) {
  try { return send(res, 200, fs.readFileSync(path.join(ROOT, 'zakazkar-vylepsena.html')), 'text/html; charset=utf-8'); }
  catch { return json(res, 404, { error:'Soubor aplikace nebyl nalezen.' }); }
}
async function handleOnlineApi(req,res,url) {
  try {
    if (req.method==='GET' && url.pathname==='/api/auth/me') {
      const user=currentUser(req); return user ? json(res,200,{user:publicUser(user)}) : json(res,401,{error:'Nejste přihlášeni.'});
    }
    if (req.method==='POST' && ['/api/auth/register','/api/auth/login'].includes(url.pathname)) {
      if(authRateLimited(req)) return json(res,429,{error:'Příliš mnoho pokusů. Zkuste to za chvíli.'});
      const input=await readJson(req), email=String(input.email||'').trim().toLowerCase(), password=String(input.password||'');
      if(!/^\S+@\S+\.\S+$/.test(email)||email.length>254) return json(res,400,{error:'Zadejte platnou e-mailovou adresu.'});
      if(password.length<10||password.length>200) return json(res,400,{error:'Heslo musí mít 10 až 200 znaků.'});
      let user=onlineData.users.find(u=>u.email===email);
      if(url.pathname==='/api/auth/register') {
        if(user) return json(res,409,{error:'Účet s tímto e-mailem už existuje. Přihlaste se.'});
        const salt=crypto.randomBytes(16).toString('hex');
        const name=String(input.name||email.split('@')[0]).trim().slice(0,100)||email.split('@')[0];
        user={id:newId(),name,email,passwordHash:crypto.scryptSync(password,salt,64).toString('hex'),salt,created:Date.now()};
        onlineData.users.push(user);
      } else {
        if(!user||crypto.scryptSync(password,user.salt,64).toString('hex')!==user.passwordHash) return json(res,401,{error:'E-mail nebo heslo není správné.'});
      }
      const token=crypto.randomBytes(32).toString('base64url');
      onlineData.sessions=onlineData.sessions.filter(s=>s.expires>Date.now()&&s.userId!==user.id);
      onlineData.sessions.push({tokenHash:sha256(token),userId:user.id,expires:Date.now()+30*24*60*60*1000});
      onlinePresence.set(user.id,Date.now()); saveOnlineData(); setSessionCookie(req,res,token); return json(res,200,{user:publicUser(user)});
    }
    if (req.method==='POST' && url.pathname==='/api/auth/logout') {
      const token=getCookie(req,'zakazkar_session'), session=onlineData.sessions.find(s=>s.tokenHash===sha256(token)); if(session)onlinePresence.delete(session.userId); onlineData.sessions=onlineData.sessions.filter(s=>s.tokenHash!==sha256(token)); saveOnlineData();
      res.setHeader('Set-Cookie','zakazkar_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0'); return json(res,200,{ok:true});
    }
    if (url.pathname.startsWith('/api/chat/')) {
      const user=requireUser(req,res); if(!user) return;
      if(req.method==='GET'&&url.pathname==='/api/chat/users') {
        const query=String(url.searchParams.get('q')||'').trim().toLowerCase();
        if(query.length<2) return json(res,200,{users:[]});
        const users=onlineData.users.filter(u=>u.id!==user.id&&(u.email.includes(query)||u.name.toLowerCase().includes(query))).slice(0,20).map(u=>({...publicUser(u),online:Date.now()-(onlinePresence.get(u.id)||0)<45000}));
        return json(res,200,{users});
      }
      if(req.method==='GET'&&url.pathname==='/api/chat/threads') {
        const peers=new Map();
        for(const m of onlineData.messages) if(m.from===user.id||m.to===user.id) {
          const peerId=m.from===user.id?m.to:m.from, old=peers.get(peerId)||{peerId,latest:m,unread:0};
          if(m.ts>old.latest.ts) old.latest=m; if(m.to===user.id&&!m.readAt) old.unread++; peers.set(peerId,old);
        }
        const threads=[...peers.values()].map(t=>{const peer=onlineData.users.find(u=>u.id===t.peerId)||{id:t.peerId,name:'Neznámý účet',email:''};return {...t,peer:{...publicUser(peer),online:Date.now()-(onlinePresence.get(peer.id)||0)<45000}};}).sort((a,b)=>b.latest.ts-a.latest.ts);
        return json(res,200,{threads});
      }
      if(req.method==='GET'&&url.pathname==='/api/chat/messages') {
        const peerId=String(url.searchParams.get('with')||'');
        if(!onlineData.users.some(u=>u.id===peerId)||peerId===user.id) return json(res,404,{error:'Účet nebyl nalezen.'});
        const messages=onlineData.messages.filter(m=>(m.from===user.id&&m.to===peerId)||(m.from===peerId&&m.to===user.id)).sort((a,b)=>a.ts-b.ts);
        let changed=false; for(const m of messages) if(m.to===user.id&&!m.readAt){m.readAt=Date.now();changed=true;} if(changed)saveOnlineData();
        return json(res,200,{messages:messages.slice(-300).map(m=>({id:m.id,from:m.from,to:m.to,text:m.text,ts:m.ts,readAt:m.readAt||null}))});
      }
      if(req.method==='POST'&&url.pathname==='/api/chat/messages') {
        const input=await readJson(req,8*1024), peerId=String(input.to||''), text=String(input.text||'').trim();
        if(!onlineData.users.some(u=>u.id===peerId)||peerId===user.id) return json(res,404,{error:'Vyberte platného příjemce.'});
        if(!text||text.length>2000) return json(res,400,{error:'Zpráva musí mít 1 až 2 000 znaků.'});
        const message={id:newId(),from:user.id,to:peerId,text,ts:Date.now(),readAt:null}; onlineData.messages.push(message); saveOnlineData();
        return json(res,201,{message:{id:message.id,from:message.from,to:message.to,text:message.text,ts:message.ts,readAt:null}});
      }
    }
    return json(res,404,{error:'Nenalezeno.'});
  } catch(error) { return json(res,error.status||500,{error:error.status?error.message:'Server chat nedokázal zpracovat požadavek.'}); }
}
const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  if (req.method === 'GET' && url.pathname === '/api/health') return json(res, 200, { ok:true, scanner:true, chat:true, sources:SOURCES.length, app:`http://127.0.0.1:${PORT}/` });
  if (req.method === 'GET' && url.pathname === '/mobilni-zakazkar.html') {
    try { return send(res,200,fs.readFileSync(path.join(ROOT,'mobilni-zakazkar.html')),'text/html; charset=utf-8'); }
    catch { return json(res,404,{error:'Mobilní stránka nebyla nalezena.'}); }
  }
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/zakazkar-vylepsena.html')) return sendHtml(res);
  if (url.pathname.startsWith('/api/auth/') || url.pathname.startsWith('/api/chat/')) return handleOnlineApi(req,res,url);
  if (req.method === 'POST' && url.pathname === '/api/scan') {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > MAX_BODY) req.destroy();
    });
    req.on('end', async () => {
      try {
        const input = JSON.parse(body || '{}');
        const keywords = Array.isArray(input.keywords) ? [...new Set(input.keywords.map(value => String(value).trim()).filter(value => value.length >= 2 && value.length <= 80))].slice(0, 80) : [];
        const sourceIds = Array.isArray(input.sourceIds) ? [...new Set(input.sourceIds.map(String))].filter(id => SOURCE_BY_ID.has(id)) : [];
        if (!keywords.length) return json(res, 400, { error:'Nejdříve nastavte obory, které hledáte.' });
        if (!sourceIds.length) return json(res, 400, { error:'Vyberte alespoň jeden zdroj v nastavení portálů.' });
        const result = await scanSources(sourceIds, keywords);
        return json(res, 200, result);
      } catch (error) {
        return json(res, 400, { error:`Sken se nepodařilo spustit: ${String(error.message || error).slice(0, 160)}` });
      }
    });
    return;
  }
  return json(res, 404, { error:'Nenalezeno.' });
});
server.listen(PORT, HOST, () => console.log(JSON.stringify({ ok:true, scanner:true, sources:SOURCES.length, app:`http://${HOST}:${PORT}/` })));
server.on('error', error => { console.error('Zakázkář server: ' + error.message); process.exit(1); });
